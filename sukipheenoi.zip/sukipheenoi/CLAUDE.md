# สุกี้ผีน้อย — ระบบสั่งอาหารร้านบุฟเฟต์

Next.js (App Router) + **JavaScript (ไม่ใช้ TypeScript)** + Supabase, deploy บน Vercel

## กฎสำคัญของโปรเจกต์นี้

### 1) Next.js เวอร์ชันล่าสุด: `params` ของ Dynamic Route เป็น Promise

ห้ามอ่านค่า `params.xxx` ตรง ๆ ต้อง unwrap ก่อนเสมอ

**Client Component** (`'use client'`) — ใช้ `use()` จาก React:

```js
'use client';
import { use } from 'react';

export default function OrderPage({ params }) {
  const { sessionId } = use(params); // ต้อง unwrap ด้วย use()
  // ...
}
```

**Server Component** — ใช้ `async/await` แทน (ห้ามเรียก `use()` แทน await ใน async component):

```js
export default async function Page({ params }) {
  const { sessionId } = await params;
}
```

`searchParams` ก็เป็น Promise เช่นกัน ให้จัดการแบบเดียวกัน

### 2) Supabase client

- ใช้ `import { supabase } from '@/lib/supabaseClient'` เท่านั้น ห้ามสร้าง client ซ้ำในไฟล์อื่น
- Environment variables: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- ค่าจริงเก็บใน `.env.local` (ไม่ commit) และตั้งซ้ำใน Vercel > Environment Variables

## โครงสร้างตารางฐานข้อมูล (มีอยู่แล้วใน Supabase — ไม่ต้องสร้างใหม่)

ให้อ้างอิงชื่อตารางและคอลัมน์ตามนี้ทั้งหมด ห้ามเดาชื่อคอลัมน์เพิ่ม

### `sessions`
| คอลัมน์ | หมายเหตุ |
|---|---|
| id | |
| table_number | หมายเลขโต๊ะ |
| adult_count | จำนวนผู้ใหญ่ |
| child_count | จำนวนเด็ก |
| status | สถานะ session |
| created_at | |

### `menu_categories`
| คอลัมน์ | หมายเหตุ |
|---|---|
| id | |
| name | ชื่อหมวด |
| sort_order | ลำดับการแสดงผล |

### `menu_items`
| คอลัมน์ | หมายเหตุ |
|---|---|
| id | |
| category_id | อ้างอิง `menu_categories.id` |
| name | ชื่อเมนู |

### `orders`
| คอลัมน์ | หมายเหตุ |
|---|---|
| id | |
| session_id | อ้างอิง `sessions.id` |
| table_number | |
| items | `jsonb` — รายการที่สั่ง |
| status | สถานะออเดอร์ |
| created_at | |

## หน้าที่วางแผนไว้

- `/` — หน้าแรก (ใช้ทดสอบว่า deploy สำเร็จ)
- `/generate-qr` — สร้าง QR ประจำโต๊ะ (ยังไม่ได้สร้าง)
- `/kitchen` — หน้าครัวดูออเดอร์ (ยังไม่ได้สร้าง)
- หน้าสั่งอาหารแบบ Dynamic Route (ขั้นตอนถัดไป) — ต้องทำตามกฎข้อ 1
