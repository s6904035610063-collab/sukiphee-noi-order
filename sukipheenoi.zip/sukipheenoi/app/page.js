import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="home">
      <svg
        className="ghost"
        viewBox="0 0 120 140"
        role="img"
        aria-label="ผีน้อย"
      >
        <path
          className="ghost-body"
          d="M20 70 C20 35 40 15 60 15 C80 15 100 35 100 70 L100 122 L85 108 L72 124 L60 108 L48 124 L35 108 L20 122 Z"
        />
        <circle className="ghost-eye" cx="45" cy="65" r="6" />
        <circle className="ghost-eye" cx="75" cy="65" r="6" />
        <ellipse className="ghost-cheek" cx="36" cy="80" rx="6" ry="4" />
        <ellipse className="ghost-cheek" cx="84" cy="80" rx="6" ry="4" />
      </svg>

      <h1>สุกี้ผีน้อย</h1>
      <p>ระบบสั่งอาหารร้านบุฟเฟต์</p>

      <nav className="home-links" aria-label="เมนูหลัก">
        <Link className="btn btn-primary" href="/generate-qr">
          สร้าง QR โต๊ะ
        </Link>
        <Link className="btn" href="/kitchen">
          หน้าครัว
        </Link>
      </nav>
    </main>
  );
}
