# สุกี้ผีน้อย

ระบบสั่งอาหารร้านบุฟเฟต์ — Next.js (App Router, JavaScript) + Supabase

> ข้อควรรู้และโครงสร้างฐานข้อมูลอยู่ใน [CLAUDE.md](./CLAUDE.md)

## เริ่มใช้งาน

```bash
npm install
cp .env.local.example .env.local   # แล้วใส่ค่าจริงจาก Supabase
npm run dev
```

ต้องใช้ Node.js 20.9 ขึ้นไป

## Deploy บน Vercel

1. Push โค้ดขึ้น GitHub แล้ว Import โปรเจกต์ใน Vercel
2. ตั้ง Environment Variables ทั้งสองตัวใน Project Settings:
   `NEXT_PUBLIC_SUPABASE_URL` และ `NEXT_PUBLIC_SUPABASE_ANON_KEY`
3. Deploy
